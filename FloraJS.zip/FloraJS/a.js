const bitkiler = {
  cicekli: {
    ad: "Çiçekli Bitki",
    saatler: ["06:00", "18:00"],
    sure: 8
  },
  yaprakli: {
    ad: "Yapraklı Bitki",
    saatler: ["06:00", "08:00", "18:00"],
    sure: 6
  },
  kaktus: {
    ad: "Kaktüs",
    saatler: ["07:00", "19:00"],
    sure: 0.2
  }
};

// Bildirim
if ("Notification" in window) {
  Notification.requestPermission();
}

function bildirimGonder(mesaj) {
  if (Notification.permission === "granted") {
    new Notification("FloraMind", { body: mesaj });
  }
}

// STATE => sayaç mantığı sağlar ilerlemeyi içinde tutar.
let seciliBitki = null;
let aktifSulamaIndex = 0;
let sulamaAktifMi = false;
let kalanSure = 0;
let sureInterval = null;

document.getElementById("baslatBtn").addEventListener("click", () => {
  if (!seciliBitki) {
    alert("Önce bitki seç");
    return;
  }

  sulamaBasladi(bitkiler[seciliBitki]);
});

// Bitki seç
document.getElementById("bitkiSec").addEventListener("change", function () {
  seciliBitki = this.value;
  aktifSulamaIndex = 0;

  if (!seciliBitki) return;

  const bitki = bitkiler[seciliBitki];

  document.getElementById("sonuc").innerHTML = `
    <h3>${bitki.ad}</h3>
    <p>Süre: ${bitki.sure} dk</p>
    <p>Saatler: ${bitki.saatler.join(", ")}</p>
  `;
});

function saatKontrol() {
  if (!seciliBitki || sulamaAktifMi) return;

  const bitki = bitkiler[seciliBitki];
  const hedefSaat = bitki.saatler[aktifSulamaIndex];

  const simdi = new Date();
  const saat = simdi.getHours().toString().padStart(2, "0");
  const dakika = simdi.getMinutes().toString().padStart(2, "0");
  const zaman = `${saat}:${dakika}`;

  if (zaman === hedefSaat) {
    sulamaBasladi(bitki);
  }
    setInterval(saatKontrol, 60000);
}
/* 
// Saat kontrol (TEST MODU)
function saatKontrol() {
  if (!seciliBitki || sulamaAktifMi) return;

  const bitki = bitkiler[seciliBitki];
  const hedefSaat = bitki.saatler[aktifSulamaIndex];

  const zaman = "18:00"; // TEST

  if (zaman === hedefSaat) {
    sulamaBasladi(bitki);
  }
}

setInterval(saatKontrol, 1000);
*/
// Sulama başlat
function sulamaBasladi(bitki) {
  if (sureInterval) clearInterval(sureInterval);

  sulamaAktifMi = true;
  kalanSure = bitki.sure * 60;
 document.getElementById("iptalBtn").disabled = false;
  document.getElementById("suladimBtn").disabled = true; // kilitleniyor süre boyunca başlama kısmı 
  document.getElementById("durum").innerText = "🚿 Sulama yapılıyor";

  bildirimGonder(`${bitki.ad} için sulama başladı`);

  sureInterval = setInterval(() => {
    kalanSure--;

    document.getElementById("kalanSure").innerText =
      `⏱️ ${Math.floor(kalanSure / 60)}:${(kalanSure % 60)
        .toString()
        .padStart(2, "0")}`;

    if (kalanSure <= 0) {
      clearInterval(sureInterval);
      document.getElementById("durum").innerText =
        "⏰ Süre doldu, 'Suladım' ile onayla";
      document.getElementById("suladimBtn").disabled = false; // bu kısımdan sonra açılacak sistem 
    }
  }, 1000);
}
document.getElementById("suladimBtn").addEventListener("click", () => {
  if (kalanSure > 0) return;
  sulamaBitti();
});
// Bitir
function sulamaBitti() {
  if (sureInterval) clearInterval(sureInterval);
  sureInterval = null;

  sulamaAktifMi = false;

  document.getElementById("suladimBtn").disabled = true;
  document.getElementById("iptalBtn").disabled = true;

  document.getElementById("kalanSure").innerText = "";
  document.getElementById("durum").innerText = "✅ Sulama kaydedildi";
}

document.getElementById("iptalBtn").addEventListener("click", () => {
  if (!sulamaAktifMi) return;

  clearInterval(sureInterval);
  sureInterval = null;
  sulamaAktifMi = false;
  kalanSure = 0;

  document.getElementById("kalanSure").innerText = "";
  document.getElementById("durum").innerText = "❌ Sulama iptal edildi";

  document.getElementById("suladimBtn").disabled = true;
  document.getElementById("iptalBtn").disabled = true;
});
